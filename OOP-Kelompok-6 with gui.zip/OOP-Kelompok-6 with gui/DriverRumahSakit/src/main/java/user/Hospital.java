package user;

public interface Hospital {
    public void addPatients(Patient patient);
    public  void removePatients(Patient patient);
}
