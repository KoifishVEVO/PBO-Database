/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package user;

/**
 *
 * @author kevin
 */
public enum DoctorType {
    GENERAL_PHYSICIAN,
    DENTIST,
    CARDIOLOGIST,
    SURGEON,
    PEDIATRICIAN,
    GYNECOLOGIST,
    NEUROLOGIST,
    ORTHOPEDIC_SURGEON,
    PSYCHIATRIST,
    ONCOLOGIST,
    DERMATOLOGIST,
    ENDOCRINOLOGIST,
    GASTROENTEROLOGIST,
    UROLOGIST,
    OTOLARYNGOLOGIST,
    OPHTHALMOLOGIST,
    RHEUMATOLOGIST,
    NEPHROLOGIST,
    PULMONOLOGIST
}

