**Repository untuk Tugas Besar OOP Kelompok 6**

Anggota Kelompok:
1. Kevin Albany Junaidi_1302223027
2. Adrian Fahren Setiawan_1302220018
3. Muhammad Farhan Ismali Fentarto_1302220046
4. Rindang Bani Isyan_1302223023
5. Adib Faizulhaq Armadhani_1302223110
6. Satrio Agul Arumbino_13022210065

- [Dokumen Inisialisasi Proyek](https://docs.google.com/document/d/1RhiNJvipRBIJTp3Ql6V-9GwgPQJLGAVshMrB9ZxEmVc/edit)
